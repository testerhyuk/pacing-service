package com.settlement.pacing.infrastructure.budget;

import com.settlement.pacing.core.budget.BudgetState;
import com.settlement.pacing.core.budget.Money;
import com.settlement.pacing.infrastructure.common.RedisKeyFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.RedisScript;

import java.time.LocalDate;
import java.util.List;

public class RedisBudgetStateStore {
    private final StringRedisTemplate redisTemplate;
    private final RedisKeyFactory keyFactory;
    private final RedisScript<List> readBudgetStateScript;
    private final RedisScript<Long> initializeBudgetStateScript;
    private final RedisScript<List> updateBudgetLimitsScript;
    private final RedisScript<List> repairBudgetStateScript;

    public RedisBudgetStateStore(
            StringRedisTemplate redisTemplate,
            RedisKeyFactory keyFactory,
            RedisScript<List> readBudgetStateScript,
            RedisScript<Long> initializeBudgetStateScript,
            RedisScript<List> updateBudgetLimitsScript,
            RedisScript<List> repairBudgetStateScript
    ) {
        this.redisTemplate = redisTemplate;
        this.keyFactory = keyFactory;
        this.readBudgetStateScript = readBudgetStateScript;
        this.initializeBudgetStateScript =
                initializeBudgetStateScript;
        this.updateBudgetLimitsScript = updateBudgetLimitsScript;
        this.repairBudgetStateScript = repairBudgetStateScript;
    }

    public ReadResult read(
            String campaignId,
            LocalDate budgetDate
    ) {
        List<?> result = redisTemplate.execute(
                readBudgetStateScript,
                List.of(
                        keyFactory.totalBudget(campaignId),
                        keyFactory.dailyBudget(
                                campaignId,
                                budgetDate
                        )
                )
        );

        if (result == null || result.isEmpty()) {
            throw new DataIntegrityViolationException(
                    "Redis 예산 상태 조회 결과가 비어있습니다"
            );
        }

        String statusValue = value(result, 0);
        ReadStatus status;

        try {
            status = ReadStatus.valueOf(statusValue);
        } catch (IllegalArgumentException exception) {
            throw corrupted(
                    "알 수 없는 Redis 예산 상태입니다: "
                            + statusValue,
                    exception
            );
        }

        if (status == ReadStatus.CORRUPTED) {
            throw corrupted(
                    "Redis 예산 Hash의 필수 필드가 누락됐습니다",
                    null
            );
        }

        if (status != ReadStatus.FOUND) {
            return new ReadResult(status, null, -1, -1);
        }

        if (result.size() != 9) {
            throw corrupted(
                    "Redis 예산 상태 필드 수가 올바르지 않습니다",
                    null
            );
        }

        try {
            BudgetState budgetState = new BudgetState(
                    campaignId,
                    budgetDate,
                    new Money(parseAmount(result, 1)),
                    new Money(parseAmount(result, 2)),
                    new Money(parseAmount(result, 3)),
                    new Money(parseAmount(result, 4)),
                    new Money(parseAmount(result, 5)),
                    new Money(parseAmount(result, 6))
            );

            return new ReadResult(
                    status,
                    budgetState,
                    parseVersion(result, 7),
                    parseVersion(result, 8)
            );
        } catch (IllegalArgumentException
                 | ArithmeticException exception) {
            throw corrupted(
                    "Redis 예산 상태 값이 올바르지 않습니다",
                    exception
            );
        }
    }

    public void initializeIfAbsent(BudgetState budgetState) {
        if (budgetState == null) {
            throw new IllegalArgumentException(
                    "BudgetState는 null일 수 없습니다"
            );
        }

        redisTemplate.execute(
                initializeBudgetStateScript,
                List.of(
                        keyFactory.totalBudget(
                                budgetState.campaignId()
                        ),
                        keyFactory.dailyBudget(
                                budgetState.campaignId(),
                                budgetState.budgetDate()
                        )
                ),
                Long.toString(
                        budgetState.totalBudget().amount()
                ),
                Long.toString(
                        budgetState.totalSpentAmount().amount()
                ),
                Long.toString(
                        budgetState.totalReservedAmount().amount()
                ),
                Long.toString(
                        budgetState.dailyBudgetLimit().amount()
                ),
                Long.toString(
                        budgetState.dailySpentAmount().amount()
                ),
                Long.toString(
                        budgetState.dailyReservedAmount().amount()
                )
        );
    }

    public LimitUpdateResult updateLimits(
            String campaignId,
            LocalDate budgetDate,
            long totalBudget,
            long dailyBudgetLimit
    ) {
        List<?> result = redisTemplate.execute(
                updateBudgetLimitsScript,
                List.of(
                        keyFactory.totalBudget(campaignId),
                        keyFactory.dailyBudget(campaignId, budgetDate)
                ),
                Long.toString(totalBudget),
                Long.toString(dailyBudgetLimit)
        );

        if (result == null || result.isEmpty()) {
            throw corrupted(
                    "Redis 예산 한도 변경 결과가 비어있습니다",
                    null
            );
        }

        LimitUpdateStatus status;
        try {
            status = LimitUpdateStatus.valueOf(value(result, 0));
        } catch (IllegalArgumentException exception) {
            throw corrupted(
                    "알 수 없는 Redis 예산 한도 변경 결과입니다",
                    exception
            );
        }

        if (status != LimitUpdateStatus.UPDATED) {
            return new LimitUpdateResult(status, -1L, -1L);
        }
        if (result.size() != 3) {
            throw corrupted(
                    "Redis 예산 한도 변경 결과 필드가 누락됐습니다",
                    null
            );
        }

        return new LimitUpdateResult(
                status,
                Long.parseLong(value(result, 1)),
                Long.parseLong(value(result, 2))
        );
    }

    public RepairResult repairIfVersionMatches(
            BudgetState repairedState,
            long expectedTotalVersion,
            long expectedDailyVersion
    ) {
        if (repairedState == null) {
            throw new IllegalArgumentException(
                    "보정할 BudgetState는 null일 수 없습니다"
            );
        }
        if (expectedTotalVersion < 0
                || expectedDailyVersion < 0) {
            throw new IllegalArgumentException(
                    "예상 예산 version은 음수일 수 없습니다"
            );
        }

        List<?> result = redisTemplate.execute(
                repairBudgetStateScript,
                List.of(
                        keyFactory.totalBudget(
                                repairedState.campaignId()
                        ),
                        keyFactory.dailyBudget(
                                repairedState.campaignId(),
                                repairedState.budgetDate()
                        )
                ),
                Long.toString(expectedTotalVersion),
                Long.toString(expectedDailyVersion),
                Long.toString(
                        repairedState.totalSpentAmount().amount()
                ),
                Long.toString(
                        repairedState.totalReservedAmount().amount()
                ),
                Long.toString(
                        repairedState.dailySpentAmount().amount()
                ),
                Long.toString(
                        repairedState.dailyReservedAmount().amount()
                )
        );

        if (result == null || result.isEmpty()) {
            throw corrupted(
                    "Redis 예산 보정 결과가 비어있습니다",
                    null
            );
        }

        RepairStatus status;
        try {
            status = RepairStatus.valueOf(value(result, 0));
        } catch (IllegalArgumentException exception) {
            throw corrupted(
                    "알 수 없는 Redis 예산 보정 결과입니다: "
                            + value(result, 0),
                    exception
            );
        }

        if (status == RepairStatus.CORRUPTED
                || status == RepairStatus.INVALID_STATE) {
            throw corrupted(
                    "Redis 예산 상태를 안전하게 보정할 수 없습니다: "
                            + status,
                    null
            );
        }

        if (status == RepairStatus.MISSING) {
            return new RepairResult(status, -1L, -1L);
        }

        if (result.size() != 3) {
            throw corrupted(
                    "Redis 예산 보정 결과 필드 수가 올바르지 않습니다",
                    null
            );
        }

        return new RepairResult(
                status,
                parseVersion(result, 1),
                parseVersion(result, 2)
        );
    }

    private long parseAmount(List<?> result, int index) {
        long parsed = Long.parseLong(value(result, index));

        if (parsed < 0) {
            throw new IllegalArgumentException(
                    "예산 금액은 음수일 수 없습니다"
            );
        }

        return parsed;
    }

    private long parseVersion(List<?> result, int index) {
        long parsed = Long.parseLong(value(result, index));

        if (parsed < 0) {
            throw new IllegalArgumentException(
                    "예산 version은 음수일 수 없습니다"
            );
        }

        return parsed;
    }

    private String value(List<?> result, int index) {
        Object value = result.get(index);

        if (value == null) {
            throw corrupted(
                    "Redis 예산 상태 값이 null입니다",
                    null
            );
        }

        return value.toString();
    }

    private DataIntegrityViolationException corrupted(
            String message,
            Throwable cause
    ) {
        return cause == null
                ? new DataIntegrityViolationException(message)
                : new DataIntegrityViolationException(
                        message,
                        cause
                );
    }

    public enum ReadStatus {
        FOUND,
        MISSING_TOTAL,
        MISSING_DAILY,
        MISSING_BOTH,
        CORRUPTED
    }

    public record ReadResult(
            ReadStatus status,
            BudgetState budgetState,
            long totalVersion,
            long dailyVersion
    ) {
        public boolean found() {
            return status == ReadStatus.FOUND;
        }
    }

    public enum LimitUpdateStatus {
        UPDATED,
        MISSING,
        INSUFFICIENT_TOTAL,
        INSUFFICIENT_DAILY,
        INVALID_LIMIT,
        CORRUPTED
    }

    public record LimitUpdateResult(
            LimitUpdateStatus status,
            long previousTotalBudget,
            long previousDailyBudgetLimit
    ) {
    }

    public enum RepairStatus {
        UPDATED,
        VERSION_MISMATCH,
        MISSING,
        CORRUPTED,
        INVALID_STATE
    }

    public record RepairResult(
            RepairStatus status,
            long totalVersion,
            long dailyVersion
    ) {
    }
}
